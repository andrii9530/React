import React, { useEffect } from "react";
import { useState } from "react";
import Box from '@mui/material/Box';
import Avatar from '@mui/material/Avatar';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import ListItemIcon from '@mui/material/ListItemIcon';
import Divider from '@mui/material/Divider';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import Tooltip from '@mui/material/Tooltip';
import PersonAdd from '@mui/icons-material/PersonAdd';
import Settings from '@mui/icons-material/Settings';
import Logout from '@mui/icons-material/Logout';
import {
    Grid,
    Pagination,
    ImageList,
    ImageListItem,
    Button,
} from "@mui/material";

const GaleryPage = () => {
    // state
    const [images, setImages] = useState([]);
    const [pagination, setPagination] = useState({ total: 0, page: 1 });
    const [category, setCategory] = useState("Banana");

    const perPage = 8;
    let imagesCategory = "Banana";
    const apiKey = "XnwpPKhh4msoD07AMkJrjHXUmXjMHaMyZYb4SAlxYB5njXsfZNSi9QKQ";
    let apiUrl = `https://api.pexels.com/v1/search?query=${category}&per_page=${perPage}&page=${pagination.page}`;

    const pageCount = Math.ceil(pagination.total / perPage);

    const pageChangeHandler = (event, value) => {
        setPagination({ ...pagination, page: value });
    };

    useEffect(() => {
        fetch(apiUrl, {
            method: "GET",
            headers: {
                Authorization: apiKey,
            },
        })
            .then((response) => {
                if (response.status === 200) {
                    return response.json();
                }
            })
            .then((data) => {
                const photos = data.photos.map((item) => item.src.medium);
                setPagination({ ...pagination, total: data.total_results });
                setImages(photos);
            })
            .catch((error) => {
                console.log(error);
            });
    }, [pagination.page, category]);

    return (
        <React.Fragment>
            <Box sx={{ display: 'flex', alignItems: 'center', textAlign: 'center' }}>
                <Button onClick={() => { imagesCategory = "Banana" }} sx={{ minWidth: 100 }}>Банан</Button>
                <Button onClick={() => { setCategory("Harry Potter") }} sx={{ minWidth: 100 }}>Гарі потер</Button>
                <Button onClick={() => { setCategory("Car") }} sx={{ minWidth: 100 }}>Машини</Button>
                <Button onClick={() => { setCategory("Love") }} sx={{ minWidth: 100 }}>Любов</Button>
                <Button onClick={() => { setCategory("Beaver") }} sx={{ minWidth: 100 }}>Бобер</Button>
            </Box>

            <Grid container columnSpacing={2} rowSpacing={1}>
                <ImageList variant="masonry" cols={3} gap={8}>
                    {images.map((item) => (
                        <ImageListItem key={item}>
                            <img
                                srcSet={`${item}?w=248&fit=crop&auto=format&dpr=2 2x`}
                                src={`${item}?w=248&fit=crop&auto=format`}
                                alt="image"
                                loading="lazy"
                            />
                        </ImageListItem>
                    ))}
                </ImageList>
                <Grid item xs={12} sx={{ display: "flex" }}>
                    <Pagination
                        page={pagination.page}
                        onChange={pageChangeHandler}
                        sx={{ m: "auto" }}
                        count={pageCount}
                        color="primary"
                    />
                </Grid>
            </Grid>
        </React.Fragment>
    );
};

export default GaleryPage;
