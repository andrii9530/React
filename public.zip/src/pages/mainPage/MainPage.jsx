import React from "react";
import GaleryPage from "../galery/GaleryPage";

export default function MainPage() {
    return (
        <GaleryPage />
    );
}
