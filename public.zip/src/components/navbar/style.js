export const btnPageStyle = {
    color: "black",
    textShadow: "2px 2px 5px black"
};